# 7 Segment Display Characters

A Pen created on CodePen.io. Original URL: [https://codepen.io/0x04/pen/AEjQwB](https://codepen.io/0x04/pen/AEjQwB).

7 segment display characters, only realized with borders. A small clock script is included.